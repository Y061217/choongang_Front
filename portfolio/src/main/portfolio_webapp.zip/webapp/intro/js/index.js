/**
 * 
 */
 
 function tel_num(num){
	var ck = Number(num);	
	if(isNaN(ck) == true){
	alert("숫자만 입력하셔야 합니다.")
	document.getElementById("user_tel").value=num.slice();						
	}
	else {

		
	}
}