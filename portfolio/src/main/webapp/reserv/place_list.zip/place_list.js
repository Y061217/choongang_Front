/**
 * 
 */
 
 var list = {
  "index_no":[101,102,103,104],
  "room_name":["아로하 향이 가득한 그린 하우스","소나무 향이 가득한 파인 하우스","온 가족이 편하게 지낼 수 있는 패밀리 하우스","로즈향이 가득한 퍼플 하우스"],
  "imgs":["./01.jpg","./02.jpg","./03.jpg","./04.jpg"],  
  "person_limit":["4","6","8","2"],
  "room_case":["1","2","3","1"]
};

var a;
for(a in list["imgs"]){	
	var room_no_html = "<div><span><input type='radio' id='ckck' name='room_no' value='"+list["index_no"][a]+"'></span>";
	var room_name_html =  "<ul><li><input type='text' value='"+list["room_name"][a]+"'readonly='readonly'></li>";
	var plimit_html =  "<li><input type='text' value='"+list["person_limit"][a]+"'readonly='readonly'></li>";
	var room_case_html =  "<li><input type='text' value='"+list["room_case"][a]+"'readonly='readonly'></li></ul><div>"; 
	var img_html = "<span><img "+"src='"+list["imgs"][a]+"' width='100%'></span>";
	document.getElementById("test").innerHTML+=room_no_html+img_html+room_name_html+plimit_html+room_case_html;
	
	

}

function ck_cfn(){
	var kk = document.getElementsByName("room_no");
	var w;
	var z = list["imgs"].length;
	for(w=0;w<=z;w++){
		if(kk[w].checked == true){
			var call_no = kk[w].value
			f.submit();
		}
	}
		
		


}